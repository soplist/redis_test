package com.blue.test;

import java.util.List;

import com.blue.bean.User;
import com.blue.dao.IUserDao;
import com.blue.dao.impl.UserDaoImpl;

public class HibernateTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HibernateTest ht = new HibernateTest();
		ht.list();
	}

	public void list(){
        IUserDao ud = new UserDaoImpl();
        List<User> list = ud.list();
        for (User user : list) {
			System.out.println("id="+user.getId()+",username="+user.getUsername()+",password="+user.getPassword());
		}
    }
}
