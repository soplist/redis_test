package com.blue.dao;

import java.util.List;

import com.blue.bean.User;

public interface IUserDao {
	public void test();
	public List<User> list();
}
