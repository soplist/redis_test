package com.blue.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.blue.dao.IUserDao;
import com.blue.util.HibernateUtil;
import com.blue.bean.User;

public class UserDaoImpl implements IUserDao {

	@Override
	public void test() {
		// TODO Auto-generated method stub
		System.out.println("call test finish!!!");
	}
	
	@Override
	public List<User> list() {

		StandardServiceRegistry sr=new StandardServiceRegistryBuilder().configure().build(); 
        SessionFactory sf=new MetadataSources(sr).buildMetadata().buildSessionFactory();        
        
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

		String hql = "from User";// Student �������� select * from t_student
        Query query = session.createQuery(hql);

		List<User> list = query.list();
        t.commit();
        session.close();
        return list;
    }
	
}
