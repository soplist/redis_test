package com.blue.service;

public interface IUserService {
	public void test();
}
