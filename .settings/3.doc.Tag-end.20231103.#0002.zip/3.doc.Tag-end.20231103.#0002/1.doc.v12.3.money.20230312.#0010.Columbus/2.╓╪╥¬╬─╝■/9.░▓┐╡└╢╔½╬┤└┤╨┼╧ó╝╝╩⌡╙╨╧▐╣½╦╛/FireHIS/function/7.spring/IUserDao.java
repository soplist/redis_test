package com.blue.dao;

public interface IUserDao {
	public void test();
}
